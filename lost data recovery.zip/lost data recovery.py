import os
import shutil
from tqdm import tqdm

SOURCE_DIR = "C:/Users"
RECOVERY_DIR = "Recovered_Files"
EXTENSIONS = (".jpg", ".png", ".pdf", ".txt", ".docx")

os.makedirs(RECOVERY_DIR, exist_ok=True)

all_files = []
for root, dirs, files in os.walk(SOURCE_DIR):
    for file in files:
        all_files.append(os.path.join(root, file))

for file_path in tqdm(all_files, desc="Scanning"):
    if file_path.lower().endswith(EXTENSIONS):
        file_name = os.path.basename(file_path)
        dest_path = os.path.join(RECOVERY_DIR, file_name)
        base, ext = os.path.splitext(file_name)
        count = 1
        while os.path.exists(dest_path):
            dest_path = os.path.join(RECOVERY_DIR, f"{base}_{count}{ext}")
            count += 1
        shutil.copy2(file_path, dest_path)

print("\n✅ Recovery Completed!")